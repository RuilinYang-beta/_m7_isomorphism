from utilities import *
from os import listdir, curdir
from graph_io import write_dot, load_graph

# Author: Ruilin Yang
# Luyao Wang has helped in implementation idea discussion and testing.

"""
This file contains the functions to "glue the pieces up", 
for example to 
"""

# "tier 0" means the function is called directly by a main somewhere,
# for i other than 0, "tier i" is helper functions of "tier i-1"
# documentation is most detailed for "tier 0" functions.


# tier 0
def get_files():
    """
    Get a list of filenames that are either .gr or .grl files in current directory
    """
    files = list(filter(lambda x: x.endswith('.grl') or x.endswith('.gr'), listdir(curdir)))
    return files


# ================================================================================
# =============================== Below AUT related ==============================
# ================================================================================

# tier 0
def AUT_problem(filename, do_m_test=False, use_wk5=False):
    """
    Encapsulate AUT function together with printing results
    """
    value = AUT(filename, do_m_test, use_wk5)
    if isinstance(value, list):
        # ------------ formatting output of AUT, when AUT reading .grl ------------
        print("========== file: {} ==========".format(filename))
        line_new = '{:<30}  {:<30} '.format("Sets of isomorphic graphs:", "Number of automorphisms:")
        print(line_new)
        for ele in value:
            print('{:<30}  {:<30} '.format(str(ele[0]), str(ele[1])))

    else:
        print("========== file: {} ==========".format(filename))
        print("The graph in {} has {} automorphisms.".format(filename, value))


# tier 1
def AUT(filename, do_m_test=False, use_wk5=False):
    """
    Input a filename, can be a .gr file or .grl file,
    compute its automorphism result and output as project manual demanded.
    Params:
        - do_m_test: is True if you want to do membership testing
    """
    if filename.endswith('.gr'):
        # file contains single graph
        return AUT_single_readfile(filename, do_m_test)

    elif filename.endswith('.grl'):
        # file contains a list of graphs
        return AUT_many(filename, do_m_test, use_wk5)


# tier 2
def AUT_single_readfile(filename, do_m_test):
    """
    Return:
        - num_auto: int, number of auto for a single graph.
    """
    with open(filename) as f:
        G = load_graph(f)

    all_v, matrix, reference = initialization_automorphism(G)

    X = []

    count, _ = get_generating_set([], [], all_v, matrix, reference, X, do_m_test)

    num_auto = order_computing(X)

    return num_auto


# tier 3, also helper of AUT_many
def AUT_single_readobj(graph_obj, do_m_test):
    """
    Return:
        - num_auto: int, number of auto for a single graph.
    """

    all_v, matrix, reference = initialization_automorphism(graph_obj)

    X = []

    count, _ = get_generating_set([], [], all_v, matrix, reference, X, do_m_test)

    num_auto = order_computing(X)

    return num_auto


# tier 2
def AUT_many(filename, do_m_test, use_wk5):
    """
    Return:
        - a list of tuples, where for each tuple,
          first ele is a list of iso class, second ele is num_auto
    """
    with open(filename) as f:
        G = load_graph(f, read_list=True)
    list_of_graphs = G[0]

    class_to_autonum = []
    GI_classes = GI_readlistgraph(filename, use_wk5)
    for ele in GI_classes:
        graph_obj = list_of_graphs[ele[0]]      # turn index into a graph object
        num_auto = AUT_single_readobj(graph_obj, do_m_test)

        class_to_autonum.append((ele, num_auto))

    return class_to_autonum


# ================================================================================
# ==================== Above are AUT related, below GI related ===================
# ================================================================================

# tier 0
def GI_problem(filename, use_wk5=False):
    """
    Encapsulate GI function together with printing results
    """
    GI_classes = GI(filename, use_wk5)
    print("========== file: {} ==========".format(filename))
    if isinstance(GI_classes, list):
        # ------------ formatting output of GI when reading .grl ------------
        print("Sets of isomorphic graphs:")
        for ele in GI_classes:
            print(ele)
    else:
        # ------------ formatting output of GI when reading .gr ------------
        print("The refined partition of this graph is {}".format(GI_classes))


# tier 1
def GI(filename, use_wk5):
    """
    filename will always be a .grl file.
    Return:
        - a list of equivalent classes.
    """
    # file contains a list of graphs
    if filename.endswith('.gr'):
        # file contains single graph
        return GI_single_readfile(filename, use_wk5)

    elif filename.endswith('.grl'):
        # file contains a list of graphs
        return GI_readlistgraph(filename, use_wk5)


# tier 2
def GI_single_readfile(filename, use_wk5):
    with open(filename) as f:
        G = load_graph(f)

    list_of_graphs = [G]

    if not use_wk5:
        mappings = refinement_wk3(list_of_graphs)
    else:
        mappings = refinement_wk5(list_of_graphs)

    return mappings


# tier 2
def GI_readlistgraph(filename, use_wk5):

    with open(filename) as f:
        G = load_graph(f, read_list=True)

    list_of_graphs = G[0]

    # use wk3 basic refinement
    if not use_wk5:
        mappings = refinement_wk3(list_of_graphs)
        # # color refinement
        # init_info = initialization(list_of_graphs)
        # info = color_refinement(init_info)
        #
        # # processing result
        # num_graphs = len(list_of_graphs)
        # mappings = from_info_to_mappings(info)
    else:
        mappings = refinement_wk5(list_of_graphs)

    bij_def, bij_g, bal_def, bal_g = typify_mappings(mappings)

    # a nested list, each element is a list of isomorphic graphs
    # these equivalent class are found directly by refinement
    GI_classes = []

    for key in bij_g:
        GI_classes.append(bij_g[key])

    # a nested list of which each ele is an equivalent class
    # these equivalent class are found by branching
    bij_from_bal = []

    # if there are undecided groups
    if len(bal_g) > 0:
        for key in bal_g:
            group = bal_g[key]  # a list of graphs that potentially is isomorphic
            if len(group) == 1:
                bij_from_bal.append(group)
            else:
                bij_from_bal.extend((typify_group(group, list_of_graphs)))

        for ele in bij_from_bal:
            GI_classes.append(ele)

    return GI_classes


# tier 3
def refinement_wk3(list_of_graphs):
    # color refinement
    init_info = initialization(list_of_graphs)
    info = color_refinement(init_info)

    # processing result
    num_graphs = len(list_of_graphs)
    mappings = from_info_to_mappings(info)

    return mappings


# tier 3
def refinement_wk5(list_of_graphs):
    info, mtx, all_v = initialization_fast_refinement_new(list_of_graphs)

    c_min = 1
    c_max = 1
    Q = [1]

    new_c_min, new_c_max, info = fast_refinement(info, mtx, all_v, c_min, c_max, Q)

    concise_info = {}
    for i in range(new_c_min, new_c_max + 1):
        concise_info[i] = info[i]

    mappings = from_info_to_mappings(concise_info)
    return mappings


# tier 3
def typify_mappings(mappings):
    """
    Params:
        - mappings, the nested dictionary of all the graphs of format
          {graph_index0: {color1: number_of_vertices_of_this_color_within_this_graph,
                          color2: number_of_vertices_of_this_color_within_this_graph, ...},
           graph_index1: {color1: number_of_vertices_of_this_color_within_this_graph,
                          color2: number_of_vertices_of_this_color_within_this_graph, ...},
           ...}
    Return:
        - see the 4 dictionaries
    """
    # a dict of format {type_key: {color1: number_of_vertices_of_this_color_within_this_graph,
    #                              color2: number_of_vertices_of_this_color_within_this_graph, ...},
    # the definition of this bijection type
    bijection_type_def = {}
    # a dict of format {type_key1: [list_of_graph_idx_that_belongs_to_this_type],
    #                   type_key2: [list_of_graph_idx_that_belongs_to_this_type],
    bijection_type_g = {}
    # a dict of format {type_key: {color1: number_of_vertices_of_this_color_within_this_graph,
    #                              color2: number_of_vertices_of_this_color_within_this_graph, ...},
    # the definition of this bijection type
    balanced_type_def = {}
    # a dict of format {type_key1: [list_of_graph_idx_that_belongs_to_this_type],
    #                   type_key2: [list_of_graph_idx_that_belongs_to_this_type],
    balanced_type_g = {}

    bijection_next_type = 0
    balanced_next_type = 0

    for g_key in mappings:
        # if this g has, every color has 1 vertice
        if is_bijection(mappings[g_key]):
            if len(bijection_type_def) == 0:
                bijection_type_def[bijection_next_type] = mappings[g_key]
                bijection_type_g[bijection_next_type] = [g_key]
                bijection_next_type += 1
            else:
                typified = False
                for t_key in bijection_type_def:
                    if same_dict_value(bijection_type_def[t_key], mappings[g_key]):
                        bijection_type_g[t_key].append(g_key)
                        typified = True
                        break
                    else:
                        pass
                if not typified:
                    bijection_type_def[bijection_next_type] = mappings[g_key]
                    bijection_type_g[bijection_next_type] = [g_key]
                    bijection_next_type += 1
        # if this g there is at least 1 color class that has >1 vertices
        else:
            if len(balanced_type_def) == 0:
                balanced_type_def[balanced_next_type] = mappings[g_key]
                balanced_type_g[balanced_next_type] = [g_key]
                balanced_next_type += 1
            else:
                typified = False
                for t_key in balanced_type_def:
                    if same_dict_value(balanced_type_def[t_key], mappings[g_key]):
                        balanced_type_g[t_key].append(g_key)
                        typified = True
                        break
                    else:
                        pass
                if not typified:
                    balanced_type_def[balanced_next_type] = mappings[g_key]
                    balanced_type_g[balanced_next_type] = [g_key]
                    balanced_next_type += 1

    return bijection_type_def, bijection_type_g, balanced_type_def, balanced_type_g


# tier 3
def typify_group(group, list_of_graphs):
    """
    Params:
        - group: a list of graph_idx that potentially is isomorphic
    Return:
        - types: a nested list, of which each element is a list of graph_idx that
                 are in the same equivalent class
    """
    types = []
    typified = []
    for i in range(0, len(group)-1):
        if group[i] not in typified:
            matches = []
            for j in range(i+1, len(group)):
                if group[j] not in typified:
                    if is_iso(list_of_graphs, [group[i], group[j]]):
                        matches.append(group[j])
                    else:
                        pass
            typified.append(group[i])
            typified.extend(matches)
            types.append([group[i]] + matches)

    return types


# tier 4
def is_iso(list_of_g, idx_list):
    p = idx_list[0]
    q = idx_list[1]

    v = extract_vertices(list_of_g, [p, q])

    # the last param is True if you want to stop at finding the first iso
    count = count_isomorphism([], [], v, True)

    if count != 0:
        return True
    else:
        return False


# ================================================================================
# =============================== above GI related ===============================
# ================================================================================



