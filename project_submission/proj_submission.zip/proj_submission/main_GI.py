from datetime import datetime
from utilities_finalization import *

"""
This file reads the graphs under GI or AUT directory, which is in the same directory as with this file, 
and solves the GI/AUT problem with desired output format.
"""

# =============== reading and select files ===============
# get a list of .gr/.grl files under current directory
all_graph_files = get_files()
print(all_graph_files)

# 1. check the console,
# 2. copy the names of files of interest
# 3. paste them into selected_files
# 4. run the program again
selected_files = []

# =============== GI ===============
for f in selected_files:
    start = datetime.now()
    # If you want to use fast refinement to fine equivalent classes, the last param is True.
    # Otherwise False.
    GI_problem(f, use_wk5=True)
    end = datetime.now()
    print("It took {} to compute".format(end - start))

