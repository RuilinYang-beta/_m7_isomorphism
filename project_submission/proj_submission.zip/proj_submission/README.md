* About main program
    * The main program for GI problem is main_GI.py
    * The main program for AUT problem is main_AUT.py
* Usage of main program / how to select instance 
    * Run it for the first time, files that ends with ".grl" or ".gr" will be printed in the console. 
    * From console, copy the file names that you want to run, and paste them into the list `selected_files` in line 18 of each program.
    * Then run the program again, and it will compute GI/AUT for the selected files.
* Important options: 
    * In both `GI_problem` and `AUT_problem`, there is a flag named `use_wk5`. When it is set to True, the program will use fast refinement to find partition of graphs into equivalent classes.
* A side note: 
    * Although it is stated that "no Python module can be imported", it is also on the manual that "the very basic ones can be imported". 
    * The import are `from os import listdir, curdir` in utilities_finalization.py, and `from datetime import datetime` in both main_GI.py and main_AUT.py. They are used for the user's convenience, not to do some magic that isn't allowed. 